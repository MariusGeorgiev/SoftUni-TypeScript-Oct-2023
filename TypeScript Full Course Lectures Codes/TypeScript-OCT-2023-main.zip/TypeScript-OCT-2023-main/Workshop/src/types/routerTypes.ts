export type RouterMap = {
  [key: string]: string;
};

export const postPage = `<div>Hello, from POST page!</div>`;

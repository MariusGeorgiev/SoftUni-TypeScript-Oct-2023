export const userPage = `<div>Hello, from USER page!</div>`;

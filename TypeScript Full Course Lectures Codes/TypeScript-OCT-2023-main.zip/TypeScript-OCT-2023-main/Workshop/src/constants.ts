export const CONFIG = {
  BASE_URL: "https://jsonplaceholder.typicode.com",
};

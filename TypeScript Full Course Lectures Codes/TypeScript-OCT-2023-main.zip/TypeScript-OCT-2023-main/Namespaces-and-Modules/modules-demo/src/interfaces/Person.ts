export interface PersonDetails {
  name: string;
  age: number;
}

export interface PersonDetailsWithoutAge {
  name: string;
}

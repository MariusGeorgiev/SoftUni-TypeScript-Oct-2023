Here we will upload the demos from TypeScript course in Softuni.

// // variable name -> descriptive
// const tableNumbersRows = [1, 2, 3, 4];
// const isMale = true;
// const hasPermission = false;

// const arrayOfPerson = [{ name: "Kiro" }, { name: "Pesho" }, { name: "Mariq" }];

// const getPersonNamesCollection = (arrayOfPerson): string => {
//   return arrayOfPerson.map((p) => p.name);
// };

// /** This function calculates angles of ... */
// const fnZxx = (a, b) => (a * b) % b ^ a;
